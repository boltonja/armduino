/*
 *  $Id: _types.h,v 1.3 2007/09/07 21:16:25 jjohnstn Exp $
 */

#ifndef _MACHINE__TYPES_H
#define _MACHINE__TYPES_H
#include <machine/_default_types.h>
#endif
