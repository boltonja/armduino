/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2012 Nick Geoca.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

/**
 * @author Nick Geoca <nickgeoca@gmail.com>
 * @brief ADC implementation.
 */

#include "ADC.h"


ADCClass Adc1(&adc1, 0);
ADCClass Adc2(&adc2, 1);
#define ADC_PIN_TO_CHNL(pin)
enum adc_modes {

};


// Set pin as analog input
//
void ADCClass::setPin(uint8_t pin)
{
    if (PIN_MAP[pin].adc_channel == 0xff) {
        return;
    }
    pinMode(pin, ANALOG_INPUT);
    // Set the adc channel to timeslot 0.
    adc_set_tslot_chnl(adc_d, 0, PIN_MAP[pin].adc_channel);
}

// bit_resolution must be 12 through 14.
// Resolution is increased by oversampling. Dithering is not performed in this class,
// so noise must be added or already be present.
void ADCClass::setRes(uint8_t bit_resolution)
{
    adc_smp_cnt smpl_count;

    this->res = bit_resolution;
    switch (this->res) {
    case 13:
        smpl_count = ADC_SMPCNT_4;
        break;
    case 14:
        smpl_count = ADC_SMPCNT_16;
        break;
    case 15:
        smpl_count = ADC_SMPCNT_64;
        break;
    default:
        smpl_count = ADC_SMPCNT_1;
        this->res = 12;
        break;
    }

    adc_set_grp_seqlen(adc_d, grp_num, smpl_cnt);
    adc_set_grp_leftshift(adc_d, grp_num, this->res - 12);
}

float ADCClass::getSamplePeriod(void)
{
    // Get adc clock
    uint32_t apb_clk = clk_get_bus_freq(adc_d->clk_id);
    uint32_t sar_clk = (2 * apb_clk / ((adc_d->regs->CONFIG & SARADC_CFGR_CLKDIV_MASK) >> SARADC_CFGR_CLKDIV_BIT));

    // 52 clk_cycles since it is 12 bit conversion.
    float conv_t = 52 / sar_clk;
    // ((64 - BMTK) + (3 * TRKMD)) / Fapb => 4 / Fapb
    float track_t = 4 / apb_clk;
    // Each bit additional resolution over 12 requires 4 times more samples
    // # bits = n ^ 4
    uint32_t smpl_cnt = 1 << ((this-res - 12) * 2);

    // (Conversion time + Track time) * sample count
    return (track_t + conv_t) * smpl_cnt;
}

#if 0
void ADCClass::stopPiping(void)
{

}
#endif

void ADCClass::pipeDataReady(void)
{
    while(this->transferPending());
}

void ADCClass::pipeOnce(uint32_t d_cnt, uint32_t *dest1)
{
    // Register tube
    if (!this->regTube()) {
        return;
    }
    // dst size, src size, dst incr, src incr
    this->setDstSrc(dma_tube_size_word, dma_tube_size_word, dma_tube_incr_word, dma_tube_incr_none);
    // Address location
    this->setAddrDstSrc((void *)dest1, (void *)&adc_d->regs->DATA);
    // Size and count
    this->setSizeCount(dma_trans_size_4, d_cnt);

    // Enable ADC to be serviced by DMA
    REG_SET_CLR(adc_d->regs->CONFIG, 1, SARADC_CFGR_DMAEN_EN);
}

void ADCClass::pipeMulti(uint32_t d_cnt, uint16_t *dest1, uint16_t *dest2, uint32_t p_cnt)
{
    // Register tube
    if (!this->regTube()) {
        return;
    }
}

uint16_t ADCClass::readData(uint8_t pin) {
    // TODO [silabs]: finish this routine
    if (PIN_MAP[pin].adc_device != adc_d) {
        return 12;
    }
    return 1;
}

